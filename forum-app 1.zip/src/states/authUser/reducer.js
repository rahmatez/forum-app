import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  authUser: null,
  isLoading: false,
  error: null,
};

const authUserSlice = createSlice({
  name: "authUser",
  initialState,
  reducers: {
    setAuthUserActionCreator: (state, action) => {
      state.authUser = action.payload.authUser;
    },
    unsetAuthUserActionCreator: (state) => {
      state.authUser = null;
    },
    setAuthUserLoadingActionCreator: (state, action) => {
      state.isLoading = action.payload.isLoading;
    },
    setAuthUserErrorActionCreator: (state, action) => {
      state.error = action.payload.error;
    },
  },
});

const {
  setAuthUserActionCreator,
  unsetAuthUserActionCreator,
  setAuthUserLoadingActionCreator,
  setAuthUserErrorActionCreator,
} = authUserSlice.actions;

export {
  setAuthUserActionCreator,
  unsetAuthUserActionCreator,
  setAuthUserLoadingActionCreator,
  setAuthUserErrorActionCreator,
};

export default authUserSlice.reducer;
