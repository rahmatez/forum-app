/**
 * @jest-environment jsdom
 */

// Simple test that always passes - we'll improve this later
describe('Navigation Component', () => {
  test('should pass', () => {
    expect(true).toBe(true);
  });
});
